// Express initialization
var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var http = require('http');

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI || 'mongodb://heroku_app31546844:9qnpesun095nhnsjnohuac6430@ds051750.mongolab.com:51750/heroku_app31546844';
var mongo = require('mongodb');
var db = mongo.MongoClient.connect(mongoUri, function (error, database_connection) {
  	if (error) throw error;

  	db = database_connection;
});

// BodyParser and CORS
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  	next();
});

// Displays student logins and locations by timestamp
app.get('/', function (request, response) {
	var page_content = '';
	var geocoder_provider = 'nominatimmapquest';
	var http_adapter = 'http';
	var geocoder = require('node-geocoder').getGeocoder(geocoder_provider, http_adapter);

	response.set('Content-Type', 'text/html');
	
	db.collection('locations', function (err, collection) {
		collection.find({"$query": {}, "$orderby": {"created_at": -1}}).toArray(function(err, cursor) {
			if (!err) {
				page_content += "<!DOCTYPE HTML><html><head><title>students</title></head><body><h1>List o Students</h1>";
				for (var count = 0; count < cursor.length; count++) {
					page_content = "<p>" 
							   + "<b>Login: </b>" + cursor[count].login 
							   + " <b>Checked-in: </b>" + cursor[count].created_at 
							   + " <b>At: </b>";
					 geocoder.reverse(cursor[count].lat, cursor[count].lng, function(err, res) { 
						var address = res[0].streetNumber + " " + res[0].streetName + ", " + res[0].city + ", " + res[0].stateCode + " " + res[0].zipcode + ", " + res[0].country;
						address = address.replace(/undefined,/g, '');
						address = address.replace(/undefined/g, '');
						response.write(page_content);
						response.write(address);
					 });
				}
			} else {
				response.send('<!DOCTYPE HTML><html><head><title>students</title></head><body><h1>Whoops, something went terribly wrong!</h1></body></html>');
			}
		});
	});

});

// Displays the JSON string (array of objects) for a specified login 
//  with the check-ins sorted in descending order by timestamp
// The mandatory parameter for this API is login. 
// If login is empty, return empty JSON array []. 
//  Example: /locations.json?login=mchow returns the check-ins 
//	 in descending order for mchow.
app.get('/locations.json', function (request, response) {
	var login = request.query.login;

	if (login == null) {
		response.send([])
	}
	else {
		db.collection('locations', function (err, collection) {
			collection.find({"$query": {"login": login}, "$orderby": {"created_at": -1}}).toArray(function(err, cursor) {
				if (err) throw err;

				response.send(cursor);
			});
		});
	}
});

// Returns a JSON string containing the characters and students locations
//  if login, lat, or lng is not sent in, no JSON string is returned
app.post('/sendLocation', function(request, response) {
	var login = request.body.login, lat = parseInt(request.body.lat), lng = parseInt(request.body.lng);
	var toInsert = {
		"login": login,
		"lat": lat,
		"lng": lng,
		"created_at": new Date()
	};

	if (login == null || lat == null || lng == null) {
		response.sendStatus(400);
	} 
	else {
		db.collection('locations', function(err, collection) {
			var id = collection.insert(toInsert, function(err, saved) {
				if (err) {
					response.sendStatus(500);
				}
				else {
					// return as toArray since thats the format Ming has
					collection.find({"$query": {}, "$orderby": {"created_at": -1}}).limit(100).toArray(function(err, cursor) {
						if (err) throw err;
						response.send(JSON.stringify({"characters":[], "students": cursor}));
					});

				}
		    });
		});
	}
});

// Displays JSON style data of redline information from mbta website 
app.get('/redline.json', function(request, response) {
	response.set('Content-Type', 'application/json');

	var options = {
	  host: 'developer.mbta.com',
	  port: 80,
	  path: '/lib/rthr/red.json'
	};

	http.get(options, function(res) {

	  res.on("data", function(chunk) {
		response.write(chunk);
	  });

	}).on('error', function(e) {
  		response.send(e.message);
	});
});



// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 5000);